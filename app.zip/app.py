from flask import Flask, request, render_template
from transformers import T5ForConditionalGeneration, T5Tokenizer
import csv

app = Flask(__name__)
model = T5ForConditionalGeneration.from_pretrained("fine_tuned_summarizer_model")
tokenizer = T5Tokenizer.from_pretrained("fine_tuned_summarizer_tokenizer")
def add_review_to_csv(food_item, review):
    with open('reviews.csv', mode='a', newline='') as file:
        writer = csv.writer(file)
        writer.writerow([food_item, review])

@app.route('/')
def index():
    return render_template('review.html')

@app.route('/submit_review', methods=['POST'])
def submit_review():
    food_item = request.form['food_item']
    review = request.form['review']
    add_review_to_csv(food_item, review)
    return render_template('review.html')

@app.route('/summarize', methods=['POST'])
def summarize():
    # Read reviews from CSV file
    reviews = []
    with open('reviews.csv', newline='', encoding='utf-8') as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            reviews.append(row['REVIEW'])
    
    # Generate abstracted summaries for each review
    review_summaries = []
    for review in reviews:
        inputs = tokenizer.encode("summarize: " + review, return_tensors="pt", max_length=512, truncation=True)
        outputs = model.generate(inputs, max_length=50, min_length=10, length_penalty=2.0, num_beams=4, early_stopping=True)
        summary = tokenizer.decode(outputs[0], skip_special_tokens=True)
        review_summaries.append(summary)

    # Combine review summaries to form the overall summary
    overall_summary = " ".join(review_summaries)

    # Generate a summary for the overall summary
    inputs = tokenizer.encode("summarize: " + overall_summary, return_tensors="pt", max_length=512, truncation=True)
    outputs = model.generate(inputs, max_length=150, min_length=50, length_penalty=2.0, num_beams=4, early_stopping=True)
    final_summary = tokenizer.decode(outputs[0], skip_special_tokens=True)
    
    return final_summary
if __name__ == '__main__':
    app.run(debug=True)
